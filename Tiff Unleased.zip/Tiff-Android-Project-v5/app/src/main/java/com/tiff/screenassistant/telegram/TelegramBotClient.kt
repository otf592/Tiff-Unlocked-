package com.tiff.screenassistant.telegram

import android.graphics.Bitmap
import com.tiff.screenassistant.data.TelegramRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class IncomingTelegramMessage(
    val updateId: Long,
    val chatId: String,
    val senderName: String,
    val text: String
)

class TelegramBotClient(private val tgRepo: TelegramRepository) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .build()

    suspend fun sendMessage(text: String, targetChatId: String = tgRepo.defaultChatId): Result<String> =
        withContext(Dispatchers.IO) {
            val token = tgRepo.botToken
            val chatId = targetChatId.ifBlank { tgRepo.defaultChatId }
            if (token.isBlank() || chatId.isBlank()) {
                return@withContext Result.failure(IllegalStateException("Telegram Bot Token or Chat ID is missing."))
            }

            try {
                val url = "https://api.telegram.org/bot$token/sendMessage"
                val payload = JSONObject().apply {
                    put("chat_id", chatId)
                    put("text", text)
                }
                val req = Request.Builder()
                    .url(url)
                    .post(payload.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(req).execute().use { resp ->
                    val body = resp.body?.string() ?: ""
                    if (!resp.isSuccessful) {
                        return@withContext Result.failure(Exception("Telegram HTTP ${resp.code}: $body"))
                    }
                    Result.success("Sent via Telegram Bot!")
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun sendScreenshot(
        bitmap: Bitmap,
        caption: String = "Current phone screen from Tiff",
        targetChatId: String = tgRepo.defaultChatId
    ): Result<String> = withContext(Dispatchers.IO) {
        val token = tgRepo.botToken
        val chatId = targetChatId.ifBlank { tgRepo.defaultChatId }
        if (token.isBlank() || chatId.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Telegram Bot Token or Chat ID is missing."))
        }

        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
            val bytes = stream.toByteArray()

            val multipartBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", chatId)
                .addFormDataPart("caption", caption)
                .addFormDataPart(
                    "photo",
                    "tiff_screen.jpg",
                    bytes.toRequestBody("image/jpeg".toMediaType())
                )
                .build()

            val url = "https://api.telegram.org/bot$token/sendPhoto"
            val req = Request.Builder().url(url).post(multipartBody).build()

            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(Exception("Telegram Photo HTTP ${resp.code}: $body"))
                }
                Result.success("Screenshot sent to Telegram!")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun autoDetectLatestChatId(): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        val token = tgRepo.botToken
        if (token.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Enter your Bot Token first."))
        }
        try {
            val url = "https://api.telegram.org/bot$token/getUpdates"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: ""
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(Exception("Telegram API error (${resp.code})"))
                }
                val root = JSONObject(body)
                val results = root.optJSONArray("result")
                    ?: return@withContext Result.failure(Exception("No messages found yet."))

                for (i in results.length() - 1 downTo 0) {
                    val upd = results.getJSONObject(i)
                    val msg = upd.optJSONObject("message") ?: upd.optJSONObject("channel_post") ?: continue
                    val chat = msg.optJSONObject("chat") ?: continue
                    val id = chat.optLong("id").toString()
                    val title = chat.optString("first_name")
                        .ifBlank { chat.optString("title") }
                        .ifBlank { "Telegram Chat" }
                    return@withContext Result.success(Pair(id, title))
                }
                Result.failure(Exception("No recent messages found. Send 'Hi' to your bot in Telegram first."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun pollNewIncomingMessages(): List<IncomingTelegramMessage> = withContext(Dispatchers.IO) {
        val token = tgRepo.botToken
        if (token.isBlank()) return@withContext emptyList()

        try {
            val offset = tgRepo.lastUpdateOffset
            val url = "https://api.telegram.org/bot$token/getUpdates?offset=$offset&timeout=10"
            val req = Request.Builder().url(url).get().build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext emptyList()
                val body = resp.body?.string() ?: return@withContext emptyList()
                val root = JSONObject(body)
                val arr = root.optJSONArray("result") ?: return@withContext emptyList()

                val messages = mutableListOf<IncomingTelegramMessage>()
                var maxUpdateId = offset

                for (i in 0 until arr.length()) {
                    val upd = arr.getJSONObject(i)
                    val updateId = upd.optLong("update_id", 0L)
                    if (updateId >= maxUpdateId) {
                        maxUpdateId = updateId + 1
                    }
                    val msg = upd.optJSONObject("message") ?: continue
                    val text = msg.optString("text", "").trim()
                    if (text.isEmpty()) continue

                    val chat = msg.optJSONObject("chat") ?: continue
                    val chatId = chat.optLong("id").toString()
                    val from = msg.optJSONObject("from")
                    val sender = from?.optString("first_name")?.ifBlank { "User" } ?: "User"

                    messages.add(IncomingTelegramMessage(updateId, chatId, sender, text))
                }

                if (maxUpdateId > offset) {
                    tgRepo.lastUpdateOffset = maxUpdateId
                }
                messages
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
