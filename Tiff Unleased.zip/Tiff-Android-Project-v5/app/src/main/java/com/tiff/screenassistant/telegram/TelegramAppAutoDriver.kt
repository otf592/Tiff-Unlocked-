package com.tiff.screenassistant.telegram

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.tiff.screenassistant.data.TelegramRepository
import com.tiff.screenassistant.service.TiffAccessibilityService
import kotlinx.coroutines.delay

class TelegramAppAutoDriver(
    private val context: Context,
    private val tgRepo: TelegramRepository
) {
    private val telegramPackages = listOf(
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "org.thunderdog.challegram"
    )

    fun isTelegramInstalled(): Boolean {
        return getInstalledTelegramPackage() != null
    }

    private fun getInstalledTelegramPackage(): String? {
        val pm = context.packageManager
        for (pkg in telegramPackages) {
            try {
                pm.getPackageInfo(pkg, 0)
                return pkg
            } catch (_: Exception) {
            }
        }
        return null
    }

    suspend fun driveSendPersonalMessage(
        recipient: String,
        message: String,
        onStatus: (String) -> Unit
    ): Boolean {
        val cleanRecipient = recipient.trim()
        val cleanMessage = message.trim()
        if (cleanRecipient.isEmpty() || cleanMessage.isEmpty()) {
            onStatus("I need both a recipient and a message to drive Telegram.")
            return false
        }

        val a11y = TiffAccessibilityService.instance
        if (a11y == null) {
            onStatus("Enable Tiff Accessibility Service first so I can drive Telegram.")
            return false
        }

        val tgPackage = getInstalledTelegramPackage()
        if (tgPackage == null) {
            onStatus("Telegram doesn't appear to be installed on this phone.")
            return false
        }

        if (cleanRecipient.startsWith("@") || (cleanRecipient.startsWith("+") && cleanRecipient.drop(1).all { it.isDigit() })) {
            onStatus("Opening Telegram chat with $cleanRecipient...")
            val uri = if (cleanRecipient.startsWith("@")) {
                val domain = cleanRecipient.removePrefix("@")
                Uri.parse("tg://resolve?domain=${Uri.encode(domain)}&text=${Uri.encode(cleanMessage)}")
            } else {
                val phone = cleanRecipient.removePrefix("+")
                Uri.parse("tg://resolve?phone=${Uri.encode(phone)}&text=${Uri.encode(cleanMessage)}")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(tgPackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                onStatus("Couldn't open Telegram deep link.")
                return false
            }

            delay(1800)
            if (tgRepo.autoTapSendInApp) {
                val sent = waitAndTapSendButton(a11y, cleanMessage)
                if (sent) {
                    onStatus("Sent to $cleanRecipient on Telegram!")
                    return true
                } else {
                    onStatus("Drafted your message to $cleanRecipient—tap Send when ready.")
                    return true
                }
            } else {
                onStatus("Drafted your message to $cleanRecipient for review.")
                return true
            }
        }

        onStatus("Opening Telegram to find $cleanRecipient...")
        val launchIntent = context.packageManager.getLaunchIntentForPackage(tgPackage)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        if (launchIntent == null) {
            onStatus("Could not launch Telegram.")
            return false
        }
        context.startActivity(launchIntent)
        delay(1500)

        var searchNode = findNodeByDescriptionOrText(a11y, listOf("Search"))
        if (searchNode == null) {
            a11y.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            delay(800)
            searchNode = findNodeByDescriptionOrText(a11y, listOf("Search"))
        }

        if (searchNode != null) {
            clickNodeOrParent(searchNode)
            delay(700)
        } else {
            a11y.performTap(91f, 8.5f)
            delay(700)
        }

        val typedSearch = typeIntoFocusedOrFirstEditText(a11y, cleanRecipient)
        if (!typedSearch) {
            onStatus("Couldn't focus Telegram's search bar.")
            return false
        }
        delay(1200)

        val matchedChatNode = findBestChatResultNode(a11y, cleanRecipient)
        if (matchedChatNode != null) {
            clickNodeOrParent(matchedChatNode)
        } else {
            a11y.performTap(45f, 22f)
        }
        delay(1100)

        val typedMsg = typeIntoMessageComposer(a11y, cleanMessage)
        if (!typedMsg) {
            onStatus("Opened chat with $cleanRecipient, but couldn't find the message box.")
            return false
        }
        delay(600)

        if (tgRepo.autoTapSendInApp) {
            val sent = waitAndTapSendButton(a11y, cleanMessage)
            if (sent) {
                onStatus("Sent to $cleanRecipient on Telegram!")
            } else {
                onStatus("Typed your message to $cleanRecipient—tap Send whenever you're ready.")
            }
        } else {
            onStatus("Drafted your message to $cleanRecipient for review.")
        }
        return true
    }

    private suspend fun waitAndTapSendButton(a11y: TiffAccessibilityService, messageText: String): Boolean {
        for (attempt in 1..4) {
            val root = a11y.rootInActiveWindow
            if (root != null) {
                val composer = findEditableNode(root)
                if (composer != null) {
                    val currentTxt = composer.text?.toString() ?: ""
                    if (currentTxt.isBlank() || currentTxt.equals("Message", ignoreCase = true)) {
                        val args = Bundle().apply {
                            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, messageText)
                        }
                        composer.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                        delay(350)
                    }
                }

                val sendNode = findNodeByDescriptionOrText(a11y, listOf("Send"))
                if (sendNode != null && clickNodeOrParent(sendNode)) {
                    return true
                }
            }
            delay(450)
        }
        return false
    }

    private fun typeIntoFocusedOrFirstEditText(a11y: TiffAccessibilityService, text: String): Boolean {
        val root = a11y.rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditableNode(root) ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun typeIntoMessageComposer(a11y: TiffAccessibilityService, text: String): Boolean {
        val root = a11y.rootInActiveWindow ?: return false
        val composer = findEditableNode(root) ?: root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        composer.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return composer.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditableNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (root.isEditable) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findEditableNode(child)
            if (found != null) return found
        }
        return null
    }

    private fun findNodeByDescriptionOrText(
        a11y: TiffAccessibilityService,
        queries: List<String>
    ): AccessibilityNodeInfo? {
        val root = a11y.rootInActiveWindow ?: return null
        return searchTree(root) { node ->
            val desc = node.contentDescription?.toString()?.trim() ?: ""
            val txt = node.text?.toString()?.trim() ?: ""
            queries.any { q ->
                desc.equals(q, ignoreCase = true) || txt.equals(q, ignoreCase = true)
            }
        }
    }

    private fun findBestChatResultNode(
        a11y: TiffAccessibilityService,
        recipientName: String
    ): AccessibilityNodeInfo? {
        val root = a11y.rootInActiveWindow ?: return null
        val screenHeight = context.resources.displayMetrics.heightPixels
        val rect = android.graphics.Rect()

        return searchTree(root) { node ->
            if (node.isEditable) return@searchTree false
            node.getBoundsInScreen(rect)
            if (rect.top < screenHeight * 0.13f) return@searchTree false
            val txt = node.text?.toString()?.trim() ?: ""
            val desc = node.contentDescription?.toString()?.trim() ?: ""
            txt.contains(recipientName, ignoreCase = true) || desc.contains(recipientName, ignoreCase = true)
        }
    }

    private fun searchTree(
        node: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val match = searchTree(child, predicate)
            if (match != null) return match
        }
        return null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 5) {
            if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            current = current.parent
            depth++
        }
        return false
    }
}
